#include <igl/circulation.h>
#include <igl/collapse_edge.h>
#include <igl/edge_flaps.h>
#include <igl/shortest_edge_and_midpoint.h>
#include <igl/read_triangle_mesh.h>
#include <igl/write_triangle_mesh.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/decimate.h>
#include <igl/writeOBJ.h>
#include <Eigen/Core>
#include <iostream>
#include <set>

int main(int argc, char * argv[])
{
  using namespace std;
  using namespace Eigen;
  using namespace igl;
  cout<<"Usage: ./703_Decimation_bin input.(off|obj|ply) output.(off|obj|ply) num_faces"<<endl;
  cout<<"  [space]  toggle animation."<<endl;
  cout<<"  'r'  reset."<<endl;

  MatrixXd V, DecU;
  MatrixXi F, DecG;
  VectorXi I,J;

  read_triangle_mesh(argv[1],V,F);

  igl::opengl::glfw::Viewer viewer;

  igl::decimate(V,F, stoi(argv[3]),DecU, DecG, J, I);
  viewer.data().clear();
  viewer.data().set_mesh(DecU,DecG);
  viewer.data().set_face_based(true);
 
  write_triangle_mesh(argv[2],DecU,DecG);

  viewer.core.background_color.setConstant(1);
  // return viewer.launch();
  return 0;
}
