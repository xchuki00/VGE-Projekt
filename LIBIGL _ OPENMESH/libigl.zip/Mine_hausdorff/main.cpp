#include <igl/readOBJ.h>
#include <igl/writeOBJ.h>
#include <igl/loop.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/circulation.h>
#include <igl/collapse_edge.h>
#include <igl/edge_flaps.h>
#include <igl/shortest_edge_and_midpoint.h>
#include <igl/read_triangle_mesh.h>
#include <Eigen/Core>
#include <iostream>
#include <igl/decimate.h>
#include <igl/hausdorff.h>
#include <igl/barycenter.h>
#include <igl/cotmatrix.h>
#include <igl/doublearea.h>
#include <igl/grad.h>
#include <igl/jet.h>
#include <igl/massmatrix.h>
#include <igl/per_vertex_normals.h>
#include <igl/readDMAT.h>
#include <igl/repdiag.h>
#include <igl/read_triangle_mesh.h>
#include "tutorial_shared_path.h"

Eigen::MatrixXd V,U;
Eigen::MatrixXi F,G;
Eigen::VectorXi J, I;

using namespace Eigen;
using namespace std;

int main(int argc, char *argv[])
{
  double dist;
  igl::read_triangle_mesh(argv[1],V,F);
  igl::read_triangle_mesh(argv[2],U,G);

  igl::hausdorff(V, F, U, G, dist);
  std::cout << "Hausdorff distance decimation: " << dist << std::endl;


}
