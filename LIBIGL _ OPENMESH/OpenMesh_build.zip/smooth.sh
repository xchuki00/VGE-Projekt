#!/bin/bash

OBJECT=$1
NUM=$2

INFILE=$OBJECT.dec.obj
OUTFILE=$OBJECT.smth.obj

time ./Smoothing $NUM data/$INFILE data/$OUTFILE

nohup ~/Documents/VGE/libigl/build/tutorial/106_ViewerMenu_bin  data/$INFILE &
nohup ~/Documents/VGE/libigl/build/tutorial/106_ViewerMenu_bin  data/$OUTFILE &i

~/Documents/VGE/libigl/build/tutorial/Mine_hausdorff_bin data/$INFILE data/$OUTFILE
