#!/bin/bash

OBJECT=$1
NUM=$2

INFILE=$OBJECT.obj
OUTFILE=$OBJECT.dec.obj

time ./OwnProject -M Q -i data/$INFILE -o data/$OUTFILE -n $NUM -v

nohup ~/Documents/VGE/libigl/build/tutorial/106_ViewerMenu_bin  data/$INFILE &
nohup ~/Documents/VGE/libigl/build/tutorial/106_ViewerMenu_bin  data/$OUTFILE &

~/Documents/VGE/libigl/build/tutorial/Mine_hausdorff_bin data/$INFILE data/$OUTFILE

