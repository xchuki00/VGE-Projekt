#!/bin/bash

OBJECT=$1
NUM=$2

INFILE=$OBJECT.obj
OUTFILE=$OBJECT.smth.obj

time ./Mine_smooth_bin data/$INFILE data/$OUTFILE $NUM

nohup ./106_ViewerMenu_bin  data/$INFILE &
nohup ./106_ViewerMenu_bin  data/$OUTFILE &

./Mine_hausdorff_bin data/$INFILE data/$OUTFILE
