#!/bin/bash

OBJECT=$1
NUM=$2

INFILE=$OBJECT.obj
OUTFILE=$OBJECT.dec.obj

time ./Mine_decimation_bin data/$INFILE data/$OUTFILE $NUM

nohup ./106_ViewerMenu_bin  data/$INFILE &
nohup ./106_ViewerMenu_bin  data/$OUTFILE &

./Mine_hausdorff_bin data/$INFILE data/$OUTFILE
